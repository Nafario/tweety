<div class="border border-gray-400 rounded-lg mb-6">
    <?php $__empty_1 = true; $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php echo $__env->make('parts._tweet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="p-4">No Tweets yet</p>
    <?php endif; ?>
</div>
<div class="mt-4">

    <?php echo e($tweets->links()); ?>

</div><?php /**PATH D:\WORK\projects\Laravel\tweety\resources\views/parts/_timeline.blade.php ENDPATH**/ ?>