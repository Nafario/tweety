<div class="bg-blue-100 border border-gray-300 rounded-lg py-4 px-6">
    <h3 class="font-bold text-xl mb-4">Following</h3>

    <ul>
        <?php $__empty_1 = true; $__currentLoopData = current_user()->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <li class="mb-4">
            <div>
                <a class="flex items-center text-sm" href="<?php echo e(route('profile', $user)); ?>">
                    <img class="rounded-full mr-2"
                        src="<?php echo e($user->avatar); ?>" alt="" width="40px">
                    <?php echo e($user->name); ?>

                </a>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No friends yet</p>
        <?php endif; ?>
    </ul>
    
</div><?php /**PATH D:\WORK\projects\Laravel\tweety\resources\views/parts/_friend-list.blade.php ENDPATH**/ ?>