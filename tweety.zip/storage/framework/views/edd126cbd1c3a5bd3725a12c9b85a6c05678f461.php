<div class="flex p-4 border-b border-gray-400">
    <div class="mr-2 flex-shrink-0">
        <a href="<?php echo e(route('profile', $tweet->user)); ?>">
            <img class="rounded-full mr-2" src="https://api.adorable.io/avatars/50/human5@adorable.io.png" alt="">
        </a>
    </div>
    <div>
        <h5 class="font-bold mb-4">
            <a href="<?php echo e(route('profile', $tweet->user)); ?>">
                <?php echo e($tweet->user->name); ?>

            </a></h5>
        <p class="text-sm">
            <?php echo e($tweet->body); ?>

        </p>
    </div>
</div><?php /**PATH D:\WORK\projects\Laravel\tweety\resources\views/components/_tweet.blade.php ENDPATH**/ ?>