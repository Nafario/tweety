<div class="border border-blue-400 rounded-lg p-8 mb-8">
    <form method="POST" action="/tweets">
        <?php echo csrf_field(); ?>
        <textarea name="body" class="w-full focus:outline-none" placeholder="What's up doc?" autofocus required></textarea>
        <hr class="my-4">
        <footer class="flex justify-between">
            <img style="width: 50px" class="rounded-full mr-2 items-center"
                src="<?php echo e(current_user()->avatar); ?>" alt="">
            <button type="submit" class="bg-blue-500 hover:bg-blue-600 rounded-lg py-2 px-4 text-white">Tweet!</button>
        </footer>
    </form>
    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-red-500 text-sm mt-2"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH D:\WORK\projects\Laravel\tweety\resources\views/parts/_publish-tweet.blade.php ENDPATH**/ ?>