<div class="flex p-4 border-b border-gray-400">
    <div class="mr-2 flex-shrink-0">
        <a href="<?php echo e(route('profile', $tweet->user->username)); ?>">
            <img style="width: 40px" class="rounded-full mr-2" src="<?php echo e($tweet->user->avatar); ?>" alt="">
        </a>
    </div>
    <div>
        <h5 class="font-bold mb-4">
            <a href="<?php echo e(route('profile', $tweet->user->username)); ?>">
                <?php echo e($tweet->user->name); ?>

            </a></h5>
        <p class="text-sm">
            <?php echo e($tweet->body); ?>

        </p>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.like-button','data' => ['tweet' => $tweet]]); ?>
<?php $component->withName('like-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['tweet' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tweet)]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
</div><?php /**PATH D:\WORK\projects\Laravel\tweety\resources\views/parts/_tweet.blade.php ENDPATH**/ ?>