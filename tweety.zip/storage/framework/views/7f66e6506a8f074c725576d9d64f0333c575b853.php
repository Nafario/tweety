<h3 class="font-bold text-xl mb-4">Following</h3>

<ul>
    <?php $__currentLoopData = auth()->user()->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li class="mb-4">
        <div>
            <a class="flex items-center text-sm" href="<?php echo e(route('profile', $user)); ?>">
                <img class="rounded-full mr-2" src="https://api.adorable.io/avatars/40/humand@adorable.io.png" alt="">
                <?php echo e($user->name); ?>

            </a>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH D:\WORK\projects\Laravel\tweety\resources\views/components/_friend-list.blade.php ENDPATH**/ ?>