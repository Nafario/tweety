<x-app>
    @include('parts._publish-tweet')

    @include('parts._timeline')
</x-app>